package es.formacion.cip.interfaces;

public class Calculadora {

    public static void main(String[] args) {
        System.out.println("Hola Mundo");
    }
}
